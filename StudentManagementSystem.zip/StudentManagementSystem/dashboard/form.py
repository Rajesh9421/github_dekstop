from dataclasses import field
from unittest import result
from django import froms

from .models import Student

class StudentForm(froms.models):
    
    class Meta:
        model = Student
        fields= "__all__"
    