from django.shortcuts import render,HttpResponse
from django.core.mail import send_mail,EmailMultiAlternatives,message
from sendEmailDemo.settings import EMAIL_HOST_USER
# Create your views here.
def index(request):

    if request.method=="POST":
        #fetch data from form
        sub=request.POST.get("subject")
        msg=request.POST.get("message")

        #approach1 
        #send_mail('Subject here', 'Here is the message.',  'from@example.com',  ['to@example.com'], fail_silently=False,)
        #send_mail(sub,msg,EMAIL_HOST_USER,['rajeshdada315@gmail.com'])

        email=EmailMultiAlternatives(sub,msg,EMAIL_HOST_USER,['rajeshsaindane422@gmail.com'])
        email.attach_file('static/images/pic2.png')
        email.send()

        return HttpResponse("email sent successfully")
    else:
        return render(request,'mail.html')    